# Fortnite Auto Queue (Android prototype)

An experimental Android Studio project for a Motorola/Android phone.

## What it does
- Opens the installed Fortnite app.
- Uses an Android AccessibilityService to look for visible accessibility labels such as
  `Return to Lobby` and `Play`.
- Attempts to activate a matching accessible control while automation is enabled.

## Important limitation
Fortnite commonly renders game menus as graphics rather than Android accessibility
controls. If the Play or Return to Lobby buttons are not exposed in the Android
accessibility tree, this prototype cannot see or click them. This project does **not**
include image recognition, OCR, or MediaProjection screen capture, so it cannot promise
fully automatic operation. It also does not bypass Fortnite anti-cheat or game rules.

## Build
1. Install Android Studio on a computer.
2. Open this project folder.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK on your Android phone.

## Use
1. Install Fortnite normally.
2. Open Fortnite Auto Queue.
3. Tap **Enable Accessibility Service**.
4. In Android Accessibility settings, enable **Fortnite Auto Queue**.
5. Return to the app and tap **Start Automation**.
6. Tap **Stop Automation** in the app to disable it.

Android requires the user to grant accessibility access manually. The service only reacts
to events while Fortnite is the active app. Test carefully; it may not find any controls
if Fortnite does not expose their labels.

## GitHub
Create a new GitHub repository and upload the contents of this folder. Do not upload
passwords, signing keys, or personal tokens.


## Nearest teammate mode (added)
The project now includes `NearestTeammateSelector`, a small Kotlin component that
chooses the closest living teammate from positions supplied by a future vision
component. The app UI displays **NEAREST teammate** as the selected follow mode.

**Not yet implemented:** detecting teammate positions from Fortnite's live screen,
determining the player's world position, navigating the map, steering, jumping from
the Battle Bus, or controlling movement. Those require a robust real-time vision and
input system; this starter project does not pretend those functions are working.
Fortnite may not expose its UI to Android Accessibility, and automated gameplay may
be restricted by Epic's rules. Check the game's rules before using automation.


## Match-long nearest teammate controller (v1.2)
Added `MatchFollowController.kt`, a pure Kotlin decision layer for the intended
match cycle:
- Battle Bus: choose the nearest living teammate as the drop target.
- Gliding / on island: keep selecting the nearest living teammate as new positions
  are supplied.
- Match finished: request the Return to Lobby step.
- Lobby: request the Play step.

This is **decision logic only**. It does not yet include a working Fortnite screen
detector, OCR/object detection model, Battle Bus phase detector, world-position
estimator, glider/navigation controller, or automated gameplay input. No actual
jumping, steering, following, returning, or re-queuing is performed by this version.
Those functions need a separately implemented and tested screen-analysis/input layer.
The earlier accessibility prototype only works with controls Fortnite exposes to
Android accessibility; Fortnite may not expose those controls.


## Build APK automatically with GitHub Actions
This project includes `.github/workflows/android-build.yml`. After uploading the
project to a GitHub repository's `main` branch, open the repository's **Actions**
tab. The workflow builds a debug APK and uploads it as an artifact named
`FortniteAutoQueue-debug-apk`. Open the successful workflow run to download it.
You can also run it manually from Actions using **Build Android APK** > **Run workflow**.
