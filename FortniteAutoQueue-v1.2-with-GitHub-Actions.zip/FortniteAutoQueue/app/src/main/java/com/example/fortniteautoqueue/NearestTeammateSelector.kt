package com.example.fortniteautoqueue

import kotlin.math.hypot

/**
 * Selects the nearest teammate from positions supplied by a future vision module.
 *
 * Coordinates must all use the same coordinate space (for example, normalized
 * screen coordinates from 0.0 to 1.0). This class does not detect teammates itself
 * and does not send movement/jump controls to Fortnite.
 */
data class TeammatePosition(
    val id: String,
    val x: Float,
    val y: Float,
    val isAlive: Boolean = true
)

object NearestTeammateSelector {
    fun selectNearest(
        playerX: Float,
        playerY: Float,
        teammates: List<TeammatePosition>
    ): TeammatePosition? {
        return teammates
            .asSequence()
            .filter { it.isAlive && it.x.isFinite() && it.y.isFinite() }
            .minByOrNull { teammate ->
                hypot(teammate.x - playerX, teammate.y - playerY)
            }
    }
}
