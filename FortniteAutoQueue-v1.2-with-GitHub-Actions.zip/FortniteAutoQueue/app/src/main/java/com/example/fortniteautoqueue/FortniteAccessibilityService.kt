package com.example.fortniteautoqueue

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Experimental label-based automation.
 *
 * It only activates controls exposed through Android's accessibility tree.
 * Many games (including some Fortnite screens) render UI as graphics, so their
 * buttons may not be visible to this service.
 */
class FortniteAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private var lastActionLabel = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences("auto_queue", MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName != "com.epicgames.fortnite") return

        val root = rootInActiveWindow ?: return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 3500L) return

        val action = findTarget(root) ?: return
        if (action.first == lastActionLabel && now - lastActionAt < 12000L) return

        val clicked = clickNodeOrParent(action.second)
        if (clicked) {
            lastActionAt = now
            lastActionLabel = action.first
        }
    }

    private fun findTarget(root: AccessibilityNodeInfo): Pair<String, AccessibilityNodeInfo>? {
        val candidates = listOf(
            "return to lobby", "return to the lobby", "back to lobby",
            "play", "ready"
        )
        return searchTree(root, candidates)
    }

    private fun searchTree(
        node: AccessibilityNodeInfo,
        candidates: List<String>
    ): Pair<String, AccessibilityNodeInfo>? {
        val label = listOfNotNull(
            node.text?.toString(),
            node.contentDescription?.toString()
        ).joinToString(" ").lowercase()

        // Prefer Return to Lobby before Play.
        val match = candidates.firstOrNull { candidate ->
            label.contains(candidate) && (candidate != "ready" || label == "ready")
        }
        if (match != null && node.isVisibleToUser && node.isEnabled) {
            return Pair(match, AccessibilityNodeInfo.obtain(node))
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = searchTree(child, candidates)
            if (found != null) return found
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 6) {
            if (current.isClickable && current.isEnabled) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
            depth++
        }
        return false
    }

    override fun onInterrupt() {
        // No continuous gesture is running.
    }
}
