package com.example.fortniteautoqueue

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("auto_queue", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }

        val title = TextView(this).apply {
            text = "Fortnite Auto Queue"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "\nThis experimental app looks for accessible on-screen button labels.\n\nIt may not work with Fortnite because games often draw their menus in a way Android accessibility cannot read."
            textSize = 16f
            gravity = Gravity.CENTER
        }

        val accessibility = Button(this).apply {
            text = "1. Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val start = Button(this).apply {
            text = "2. Start Automation"
            setOnClickListener {
                prefs.edit().putBoolean("enabled", true).apply()
                Toast.makeText(this@MainActivity, "Automation enabled. Open Fortnite when ready.", Toast.LENGTH_LONG).show()
                launchFortnite()
            }
        }

        val stop = Button(this).apply {
            text = "Stop Automation"
            setOnClickListener {
                prefs.edit().putBoolean("enabled", false).apply()
                Toast.makeText(this@MainActivity, "Automation stopped.", Toast.LENGTH_SHORT).show()
            }
        }

        listOf(title, info, accessibility, start, stop).forEach { view ->
            layout.addView(view, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 18 })
        }
        setContentView(layout)
    }

    private fun launchFortnite() {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.epicgames.fortnite")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Fortnite package not found. Install Fortnite first.", Toast.LENGTH_LONG).show()
        }
    }
}
