package com.example.fortniteautoqueue

/**
 * Pure decision logic for the intended match-long nearest-teammate mode.
 *
 * A future screen-analysis module must provide teammate positions and match phase.
 * This controller deliberately does not capture the screen or send game inputs.
 */
enum class MatchPhase {
    LOBBY, BATTLE_BUS, GLIDING, ON_ISLAND, MATCH_FINISHED, UNKNOWN
}

enum class SuggestedAction {
    WAIT, LOOK_FOR_PLAY, WAIT_FOR_BUS, JUMP_AND_GLIDE_TOWARD_TEAMMATE,
    FOLLOW_NEAREST_TEAMMATE, RETURN_TO_LOBBY, REQUEUE, NEED_SCREEN_DETECTION
}

data class MatchSnapshot(
    val phase: MatchPhase,
    val playerX: Float? = null,
    val playerY: Float? = null,
    val teammates: List<TeammatePosition> = emptyList()
)

data class FollowDecision(
    val action: SuggestedAction,
    val targetTeammate: TeammatePosition? = null,
    val explanation: String
)

class MatchFollowController {
    fun decide(snapshot: MatchSnapshot): FollowDecision {
        return when (snapshot.phase) {
            MatchPhase.LOBBY -> FollowDecision(
                SuggestedAction.LOOK_FOR_PLAY,
                explanation = "Lobby detected: look for the Play control."
            )
            MatchPhase.BATTLE_BUS -> {
                val target = nearest(snapshot)
                FollowDecision(
                    SuggestedAction.JUMP_AND_GLIDE_TOWARD_TEAMMATE,
                    target,
                    if (target == null) "Waiting for teammate positions."
                    else "Selected the nearest living teammate for the drop."
                )
            }
            MatchPhase.GLIDING, MatchPhase.ON_ISLAND -> {
                val target = nearest(snapshot)
                FollowDecision(
                    if (target == null) SuggestedAction.NEED_SCREEN_DETECTION
                    else SuggestedAction.FOLLOW_NEAREST_TEAMMATE,
                    target,
                    if (target == null) "No teammate positions supplied by screen analysis."
                    else "Follow target updated to the nearest living teammate."
                )
            }
            MatchPhase.MATCH_FINISHED -> FollowDecision(
                SuggestedAction.RETURN_TO_LOBBY,
                explanation = "Match finished: look for the Return to Lobby control."
            )
            MatchPhase.UNKNOWN -> FollowDecision(
                SuggestedAction.NEED_SCREEN_DETECTION,
                explanation = "Waiting for reliable match-state detection."
            )
        }
    }

    private fun nearest(snapshot: MatchSnapshot): TeammatePosition? {
        val x = snapshot.playerX ?: return null
        val y = snapshot.playerY ?: return null
        return NearestTeammateSelector.selectNearest(x, y, snapshot.teammates)
    }
}
